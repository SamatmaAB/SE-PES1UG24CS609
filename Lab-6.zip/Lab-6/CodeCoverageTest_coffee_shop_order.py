import pytest

from coffee_shop_order import check_espresso_machine, process_order_batch


def test_batch_validation():
    with pytest.raises(ValueError):
        process_order_batch(None, 0.0)
    with pytest.raises(ValueError):
        process_order_batch([], -0.1)


def test_paid_sizes_customizations_and_discount():
    orders = [
        {"paid": False, "size": "bad"},
        {"paid": True, "size": "small", "is_member": True,
         "customizations": [{"type": "syrup", "cost": 1.0}]},
        {"paid": True, "size": "medium", "is_member": False,
         "customizations": [{"type": "standard", "cost": -1.0},
                            {"type": "allergen_alert"},
                            {"type": "standard", "cost": 0.5}]},
        {"paid": True, "size": "large", "customizations":
         [{"type": "syrup", "cost": 2.0}]},
        {"paid": True, "size": "invalid"},
    ]
    result = process_order_batch(orders, 0.1)
    assert result == {"total": 17.71, "status": "COMPLETED"}


def test_strict_allergy_results_in_no_sale():
    order = {
        "paid": True,
        "size": "small",
        "strict_allergy": True,
        "customizations": [{"type": "allergen_alert"}],
    }
    assert process_order_batch([order], 0.0) == {"total": 0.0, "status": "NO_SALE"}


def test_rejection_audit_status():
    orders = [{"paid": True, "size": "bad"} for _ in range(5)]
    assert process_order_batch(orders, 0.0)["status"] == "AUDIT_REJECTED"


@pytest.mark.parametrize(
    "cycles,expected",
    [([], "NO_DATA"), ([[90.0, 97.0, 90.0]], "OPTIMAL"),
     ([[97.0, 97.0]], "SHUTDOWN")],
)
def test_machine_cycle_results(cycles, expected):
    assert check_espresso_machine(cycles) == expected
