import pytest

from coffee_shop_order import check_espresso_machine, process_order_batch


def test_single_medium_coffee():
    orders = [
        {
            "paid": True,
            "size": "medium",
            "strict_allergy": False,
            "is_member": False,
            "customizations": [{"type": "standard", "cost": 0.5}],
        }
    ]
    result = process_order_batch(orders, 0.1)
    assert result == {"total": 5.5, "status": "COMPLETED"}


@pytest.mark.parametrize(
    "orders,tax_rate",
    [
        (None, 0.0),  # invalid orders
        ([], -0.01),  # invalid tax rate
    ],
)
def test_invalid_batch_inputs_raise_value_error(orders, tax_rate):
    with pytest.raises(ValueError, match="Invalid orders list or tax rate"):
        process_order_batch(orders, tax_rate)


def test_unpaid_order_is_skipped_and_empty_batch_is_no_sale():
    result = process_order_batch([{"paid": False, "size": "not-a-size"}], 0.2)
    assert result == {"total": 0.0, "status": "NO_SALE"}


def test_empty_order_list_is_no_sale():
    assert process_order_batch([], 0.0) == {"total": 0.0, "status": "NO_SALE"}


def test_all_sizes_member_discount_and_syrup_cap():
    orders = [
        {"paid": True, "size": "small", "is_member": True,
         "customizations": [{"type": "syrup", "cost": 1.0}]},
        {"paid": True, "size": "large", "is_member": False,
         "customizations": [{"type": "syrup", "cost": 2.0}]},
    ]
    # (3 + 1) * 0.9 + (6 + 1.5) = 11.1; tax = 1.11
    assert process_order_batch(orders, 0.1) == {
        "total": 12.21,
        "status": "COMPLETED",
    }


def test_unknown_size_is_rejected_without_sale():
    result = process_order_batch([{"paid": True, "size": "extra-large"}], 0.0)
    assert result == {"total": 0.0, "status": "NO_SALE"}


def test_negative_customization_cost_is_rejected_and_skipped():
    order = {
        "paid": True,
        "size": "small",
        "customizations": [{"type": "standard", "cost": -2.0}],
    }
    assert process_order_batch([order], 0.0) == {
        "total": 3.0,
        "status": "COMPLETED",
    }


def test_order_without_customizations_uses_base_price():
    assert process_order_batch([{"paid": True, "size": "medium"}], 0.0) == {
        "total": 4.5,
        "status": "COMPLETED",
    }


def test_allergy_alert_non_strict_rejects_modifier_but_keeps_item():
    order = {
        "paid": True,
        "size": "small",
        "strict_allergy": False,
        "customizations": [
            {"type": "allergen_alert", "cost": 0.0},
            {"type": "standard", "cost": 0.5},
        ],
    }
    assert process_order_batch([order], 0.0) == {
        "total": 3.5,
        "status": "COMPLETED",
    }


def test_strict_allergy_zeroes_item_and_stops_customizations():
    order = {
        "paid": True,
        "size": "large",
        "strict_allergy": True,
        "is_member": True,
        "customizations": [
            {"type": "allergen_alert", "cost": 0.0},
            {"type": "standard", "cost": 5.0},
        ],
    }
    assert process_order_batch([order], 0.1) == {
        "total": 0.0,
        "status": "NO_SALE",
    }


def test_more_than_four_rejections_trigger_audit_status():
    # Each unknown paid size adds one rejection; four are allowed, five trigger audit.
    orders = [{"paid": True, "size": "invalid"} for _ in range(5)]
    assert process_order_batch(orders, 0.0) == {
        "total": 0.0,
        "status": "AUDIT_REJECTED",
    }


@pytest.mark.parametrize(
    "cycles,expected",
    [
        ([], "NO_DATA"),
        ([[]], "OPTIMAL"),
        ([[96.0, 97.0, 96.0, 98.0]], "OPTIMAL"),
        ([[97.0, 96.0, 97.0]], "OPTIMAL"),
        ([[97.0, 97.0]], "SHUTDOWN"),
        ([[90.0], [98.0, 98.0]], "SHUTDOWN"),
    ],
)
def test_espresso_temperature_cycles(cycles, expected):
    assert check_espresso_machine(cycles) == expected
