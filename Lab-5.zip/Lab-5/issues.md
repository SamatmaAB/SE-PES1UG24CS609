# Lab 5 — Static Code Analysis: Issues Found and Fixes

**File analysed:** `energy_system.py`
**Tools:** Pylint 4.1.3, Bandit 1.9.4, Flake8 7.4.1

**Reports**
- Before fixes: `before/pylint_report.txt`, `before/bandit_report.txt`, `before/flake8_report.txt`
- After fixes: `pylint_report.txt`, `bandit_report.txt`, `flake8_report.txt`

**Baseline:** Pylint **6.49/10**, Bandit **1 issue (Medium)**, Flake8 **12 issues**
**After fixes:** Pylint **10.00/10**, Bandit **0 issues**, Flake8 **0 issues**

## Issue table (high/medium severity first)

| Issue | Type | Line(s) | Description | Fix Approach |
|-------|------|---------|-------------|--------------|
| Insecure use of `eval()` on user input | Security — Bandit **B307** (Medium), Pylint W0123 | 63 | `record_reading("M-01", eval(adjustment))` executes whatever Python the user types. Input such as `__import__('os').system('...')` is arbitrary code execution (CWE-78, RCE risk). | Added a `parse_units()` helper that uses `ast.literal_eval` (literals only, no code execution) and validates the result is a number. `eval` no longer appears in the file. |
| Negative meter readings accepted → negative bills | Bug (not flagged by any tool) | 12–14, 55, 63 | `record_reading` accepted negative `units`, so `record_reading("M-03", -50)` produced `Bill M-03: -192.50`, and any negative value typed at the prompt was accepted. | `record_reading` now raises `ValueError` for negative units and `parse_units` rejects negative/non-numeric input; `main` reports the rejection instead of silently corrupting the data. |
| Mutable default argument `history=[]` | Bug — Pylint **W0102** | 12 | The default list is created once and shared by every call, so readings for different meters pile into the same list (`Readings stored so far: 3`). | Default changed to `history=None` and a fresh list is created inside the function when it is `None`. |
| Bare `except:` | Bug / Quality — Pylint **W0702**, Flake8 **E722** | 44 | A bare `except:` swallows *every* exception (including `KeyboardInterrupt`/`SystemExit`) and hides real load failures. | Catch only the expected errors: `except (OSError, json.JSONDecodeError)`. |
| Global mutable state via `global` statements | Design — Pylint **W0603** | 27, 40 | Module-level `meters` and the rate constants were mutated through `global`, making state hard to follow and test. | Encapsulated the meters, rates and file path in an `EnergySystem` class; `raise_rates` now updates `self.rates`. |
| Missing docstrings | Quality — Pylint **C0114**, **C0116** | 1, 12, 17, 26, 32, 39, 47, 52 | No module, class or function documentation at all. | Added a module docstring plus docstrings for every class, method and function. |
| File handles not managed safely / no encoding | Quality — Pylint **R1732** | 42–43, 48 | `open()` results were not guaranteed to be closed on error and used the platform default encoding. | Use `with open(..., encoding="utf-8")` in `load()` and `save()`. |
| Unnecessary `elif`/`else` after `return` | Quality — Pylint **R1705** | 19–24 | Extra nesting after a `return` that always exits the branch. | Replaced with a plain `if` and a single final `return`. |
| Old `%`-style string formatting | Style — Pylint **C0209** | 59, 60, 66 | `print("... %.2f" % value)` instead of f-strings. | Converted all formatting to f-strings. |
| Unused import | Style — Pylint **W0611**, Flake8 **F401** | 2 | `import sys` was never used. | Removed the import. |
| Lines longer than 79 characters | Style — Flake8 **E501** | 24, 62 | Lines were 88 and 86 characters long. | Wrapped the tier-3 expression and split the prompt into a separate `prompt` variable. |
| Missing blank lines between definitions | Style — Flake8 **E302**, **E305** | 12, 17, 26, 32, 39, 47, 52, 68 | Top-level definitions require two blank lines. | Added the required blank lines (PEP 8). |

## Verification

After the fixes, the program still works and the problems are gone:

```
$ python energy_system.py
Rejected reading: units must be non-negative, got -50
Readings stored so far: 1
Bill M-01: 495.00
Bill M-02: 4290.00
Spikes: ['M-02']
Extra units for M-01 as an expression (Enter for 0):
Bill M-01 after reload: 550.00
```

- `pylint energy_system.py` → `Your code has been rated at 10.00/10`
- `bandit -r energy_system.py` → `No issues identified.`
- `flake8 energy_system.py` → no output (clean)
