"""Energy consumption and tariff calculator.

Records meter readings, computes a three-tier electricity bill, flags meters
with unusually high usage and stores readings in ``meters.json``.
"""

import ast
import json
from datetime import datetime

DEFAULT_DATA_FILE = "meters.json"
SPIKE_LIMIT = 500
TIER_1_LIMIT = 100
TIER_2_LIMIT = 300


class EnergySystem:
    """Track meter readings and compute tiered electricity bills."""

    def __init__(self, rates, data_file=DEFAULT_DATA_FILE):
        """Store the tier rates and the path to the data file."""
        self.rates = list(rates)
        self.data_file = data_file
        self.meters = {}

    def record_reading(self, meter_id, units, history=None):
        """Record a reading and return the updated history list."""
        if history is None:
            history = []
        if units < 0:
            raise ValueError(f"units must be non-negative, got {units}")
        history.append((meter_id, units, str(datetime.now())))
        self.meters[meter_id] = self.meters.get(meter_id, 0) + units
        return history

    def compute_bill(self, meter_id):
        """Return the tiered bill for a meter."""
        units = self.meters[meter_id]
        if units <= TIER_1_LIMIT:
            return units * self.rates[0]
        if units <= TIER_2_LIMIT:
            return (
                TIER_1_LIMIT * self.rates[0]
                + (units - TIER_1_LIMIT) * self.rates[1]
            )
        return (
            TIER_1_LIMIT * self.rates[0]
            + (TIER_2_LIMIT - TIER_1_LIMIT) * self.rates[1]
            + (units - TIER_2_LIMIT) * self.rates[2]
        )

    def raise_rates(self, percent):
        """Increase every tier rate by the given percentage."""
        factor = 1 + percent / 100
        self.rates = [rate * factor for rate in self.rates]

    def flag_spikes(self):
        """Return the ids of meters whose usage exceeds the spike limit."""
        return [
            meter_id
            for meter_id, usage in self.meters.items()
            if usage > SPIKE_LIMIT
        ]

    def load(self):
        """Load meter data, falling back to an empty store on failure."""
        try:
            with open(self.data_file, encoding="utf-8") as handle:
                self.meters = json.load(handle)
        except (OSError, json.JSONDecodeError):
            self.meters = {}

    def save(self):
        """Write meter data to the data file."""
        with open(self.data_file, "w", encoding="utf-8") as handle:
            json.dump(self.meters, handle)


def parse_units(text):
    """Parse a user-supplied number without executing arbitrary code.

    ast.literal_eval only accepts Python literals, so unlike eval it cannot
    run arbitrary code taken from the input.
    """
    try:
        value = ast.literal_eval(text)
    except (ValueError, SyntaxError) as error:
        raise ValueError(f"invalid expression: {text!r}") from error
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"expected a number, got {value!r}")
    if value < 0:
        raise ValueError(f"units must be non-negative, got {value}")
    return value


def main():
    """Run a small demonstration of the energy system."""
    system = EnergySystem([3.5, 5.0, 7.5])
    history = system.record_reading("M-01", 120)
    system.record_reading("M-02", 640)
    try:
        system.record_reading("M-03", -50)
    except ValueError as error:
        print(f"Rejected reading: {error}")
    print(f"Readings stored so far: {len(history)}")
    system.raise_rates(10)
    print(f"Bill M-01: {system.compute_bill('M-01'):.2f}")
    print(f"Bill M-02: {system.compute_bill('M-02'):.2f}")
    print(f"Spikes: {system.flag_spikes()}")
    prompt = "Extra units for M-01 as an expression (Enter for 0): "
    adjustment = input(prompt) or "0"
    try:
        units = parse_units(adjustment)
    except ValueError as error:
        print(f"Rejected input: {error}")
        units = 0
    system.record_reading("M-01", units)
    system.save()
    system.load()
    print(f"Bill M-01 after reload: {system.compute_bill('M-01'):.2f}")


if __name__ == "__main__":
    main()
